'use client';
import { useState } from 'react';

export default function ContactPage() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState('');

  const handleChange = (e: any) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: any) => {
    e.preventDefault();
    setStatus('Sending...');
    try {
      const res = await fetch('/api/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });

      const data = await res.json();
      if (data.success) {
        setStatus('Email sent successfully!');
        setForm({ name: '', email: '', message: '' });
      } else {
        setStatus('Failed to send email.');
      }
    } catch (error) {
      setStatus('Something went wrong.');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 max-w-md mx-auto p-4">
      <input name="name" onChange={handleChange} value={form.name} placeholder="Your Name" className="w-full p-2 border rounded" />
      <input name="email" type="email" onChange={handleChange} value={form.email} placeholder="Your Email" className="w-full p-2 border rounded" />
      <textarea name="message" onChange={handleChange} value={form.message} placeholder="Message" className="w-full p-2 border rounded" />
      <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded">Send</button>
      {status && <p>{status}</p>}
    </form>
  );
}
